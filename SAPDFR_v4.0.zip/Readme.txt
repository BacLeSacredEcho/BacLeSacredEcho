San Andreas Police Department: First Response (SAPD:FR)
Version: 4.0
Creator/Developer: OJdoesIt/HeresOtis
Release Date: 5/11/2012
Site: http://lumiprints.com/FRmods/forum/


What is SAPD:FR?
It is a CLEO modification that allows the player to roleplay as a police officer.


Features:
	- Go on duty and choose skin and vehicle
	- Receive several callouts to respond to
	- Request police backup, medic assistance, firetruck assistance, and SWAT backup
	- Pull vehicles over and partake in traffic stops
	- Start/join high speed pursuits
	- Arrest/frisk/heal any person
	- Get all close police officers to kill any ped you aim at


How To Install:
	1. Put all .cs file(s) in the CLEO folder.
	2. Put all .fxt file(s) in the CLEO\CLEO_TEXT folder.
	3. Put the PoliceDB.ini in the CLEO folder.
	4. Put PolData.txd in models\txd folder


How To Use: 
	1. Press ALT + P to start SAPD:FR.
	2. View the .pdf to learn the keypresses.


Join the SAPD:FR official site:
http://lumiprints.com/FRmods/forum/



Note: This mod should not be hosted on any other site without my permission.


Copyright �2012 OJdoesIt
All rights reserved.
































